// Copyright 2017 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

#define issue20266 20266

#ifndef def20266
#error "expected def20266 to be defined"
#endif
